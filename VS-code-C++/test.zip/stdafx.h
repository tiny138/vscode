//stafx.h :包含标准系统文件的包含文件
//不是很懂，反正为_tmain服务
// #pragma once
#include "targetver.h"

#include <stdio.h>
#include <tchar.h>
#include <math.h>
