// #pragma once
//要求的最低版本
#ifndef _WIN32_WINNT
#define _WIN32_WINNT 0x0600
#endif